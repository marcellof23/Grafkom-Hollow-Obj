/* Main const*/

var maxNumVertices = 200000;

var cindex = 0;
