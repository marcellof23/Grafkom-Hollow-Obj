class ModelGL {
  constructor() {
    this.gl;
    this.canvas;

    this.cubePoints = [];
    this.cubeColors = [];
  }

  load_data(data) {}
}
